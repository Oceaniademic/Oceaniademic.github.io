			  - Touhou Danmakufu ph3 -
			- Happy Hikariko New Year! -
		       - New Year! Hikariko Aosagi! -
			     By HumanReploidJP
0===============================================================================================0
|/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/|
0===============================================================================================0

	Touhou Shinjutou ~ Hollow Song of Birds
		Date: May 12th, 2018

	This script: January 1st-3rd, 2019

This script is made after the trial version of Hollow Song of Birds. Don't get so serious.

I'll be making my own item script right after this, because I missed it right on New Year.
Note that the item script is the Default Item Script in Danmakufu.

0===============================================================================================0
| 		Credits to:
0===============================================================================================0
--- ZUN (@Team Shanghai Alice)
	- Mima (the puchi-esque), Koishi Komeiji
	  - (Original characters are part of the Touhou Project by ZUN.)

	- (Made in style based on touhou characters by HumanReploidJP. NO GAME DATA OR SCREENSHOTS, SELF-MADE BASED ON TOUHOU CHARACTERS.)


--- Boss: "Hikariko Aosagi"
	- Originally from: "Touhou Shinjutou/Eastern Pearl Island ~ Hollow Song of Birds" (Sorry if I'm not good at Japanese)
	  - Game made by: raichu, Shijimi Nono, Ido

	  - Art made by: ANMITA (char designer of HSoB)

==========================================================================================================================================
--- Music: "Noble Green Cinderella"
	- Original Composer: Wanwan
	  - Arranged by: HumanReploidJP

	- Credits with permission:
		- Wanwan (composer of HSoB)

		- DJ Abner (the "mima" part which I ask; from The THFG "The Shattered Sky")

==========================================================================================================================================
--- HumanReploidJP (*TBA* @MiraikeiBudoukan)
	- System for DNH ph3, sound effects, interface, shotsheet, background, dialogue.

	- Arranger for music, dot painter, dnh entry script storywriter.